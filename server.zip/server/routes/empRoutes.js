import express from 'express'
import TableController from '../controllers/TableController.js'
import staffController from '../controllers/staffController.js';

const router = express.Router();


router.get('/:table', TableController.display);
router.post('/:table', TableController.add);
router.put('/:table/:staff_id', TableController.edit);
router.delete('/:table/:staff_id', TableController.delete);
router.post('/:table/filter-sort', TableController.filtersort);
router.post('/staff/:role', staffController.add_check);
export default router;
