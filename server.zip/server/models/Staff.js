import {connect} from '../database.js'
import Model from './Model.js'

const Staff = {
  add_check: async (role, values) => {
    const result = await Model.create('staff', values);
    if (result.err) {
      return {err: result.err};
    }
    const records = await Model.display('staff', null, {});
    const id = {
      receptionist: 'receptionist_id',
      cleaning_staff: 'cleaner_id',
      coach: 'coach_id',
      facilities_manager: 'manager_id'
    }
    const db = connect();

    let sql = `SELECT * FROM ${role} WHERE ${id[role]} = '${values.staff_id}'`;
    const check_staff = await db.query(sql);
    console.log('be result', check_staff)
    if (check_staff[0].length == 0) {
      return {job_title_error: true, result: records};
    }
    else {
      return {result: records};
    }
  }
};

export default Staff;