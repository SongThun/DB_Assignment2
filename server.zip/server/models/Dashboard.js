import {connect} from '../database.js'


const Dashboard = {
  getAttributes: async (procedure) => {
    const db = connect();
    let sql = `CALL badminton_court_db.${procedure}();`;
    //let attributes = {};
    const result = await db.query(sql);
    // console.log(result);
    // result[0].forEach(row => {
    //   attributes[row.COLUMN_NAME] = row.DATA_TYPE;
    // });
    return result[0][0];
  },
  
  display: async function(table, attrFilter, attrSort) {
    const db = connect();
    const attributes = await this.getAttributes(table);
    const result = await db.query(sql);
    //console.log(result);
    return result[0]; 
  },
  
}

export default Dashboard
