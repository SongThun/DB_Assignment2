import Staff from "../models/Staff.js";

const staffController = {
  add_check: async (req, res) => {
    const values = req.body;
    const role = req.params.role;
    const result = await Staff.add_check(role, values);
    console.log(result);
    if (result.err) {
      return res.json({err: result.err});
    }
    else return res.json(result);
  }
};

export default staffController;