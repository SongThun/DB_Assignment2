import Rental from '../models/Rental.js'
import Model from '../models/Model.js'

const RentalController = {
  findAvailableAdd: async (req, res) => {
    const params = [
      req.body.court_date,
      req.body.start_time,
      req.body.end_time
    ]
    const result = await Rental.find(params);
    let distinctSet = {};
    for (const key in result[0]) {
      distinctSet[key] = new Set();
      result.forEach(item => distinctSet[key].add(item[key]));
      distinctSet[key] = Array.from(distinctSet[key]);
    }
    return res.json({
      result: result ? result : "",
      distinct: distinctSet,
      attributes: ['court_id', 'court_type', 'court_price'],
      primaryKeys: ['court_id']
    })
  },
  findAvailableEdit: async (req, res) => {
    const result = await Rental.findWithEdit(req.body.prev, req.body.new);
    let distinctSet = {};
    for (const key in result[0]) {
      distinctSet[key] = new Set();
      result.forEach(item => distinctSet[key].add(item[key]));
      distinctSet[key] = Array.from(distinctSet[key]);
    }
    return res.json({
      result: result ? result : "",
      distinct: distinctSet,
      attributes: ['court_id', 'court_type', 'court_price'],
      primaryKeys: ['court_id']
    })
  }
    
  
}

export default RentalController;