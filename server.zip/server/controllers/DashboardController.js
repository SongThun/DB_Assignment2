import Dashboard from '../models/Dashboard.js'

const DashboardController ={
  display: async (req,res) => {
    const procedure=req.params.procedure;
    const result = await Dashboard.getAttributes(procedure);
    //const result = await Dashboard.display(procedure,null,{});
  //   if (result.length>0){
  //     let distinctSet={};
  //     for (const key in result[0]){
  //       distinctSet[key] = new Set();
  //       result.forEach(item => distinctSet[key].add(item[key]));
  //       distinctSet[key] = Array.from(distinctSet[key]);
  //     }
  //     const attributes = await Model.getAttributes(procedure);

  //     return res.json({
  //       result: result, 
  //       distinct: distinctSet,
  //       attributes: Object.keys(attributes)
  //     });
  // } else 
  // return res.json({
  //   result: [],
  //   distinct: {},
  //   attributes: []
  // });
  return res.json(result);
  }
}

export default DashboardController;